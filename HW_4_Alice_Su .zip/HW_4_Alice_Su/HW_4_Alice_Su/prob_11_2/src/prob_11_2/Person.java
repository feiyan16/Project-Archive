package prob_11_2;

public class Person {
	
	// data fields
	private String name;
	private String address;
	private double phoneNo;
	private String email;

	// no-arg constructor w/ default values
	public Person() {
		name = null;
		address = null;
		phoneNo = 0;
		email = null;
	}
	
	// constructor to set values
	public Person(String n, String a, double p, String e) {
		this.setName(n);
		this.setAddress(a);
		this.setPhone(p);
		this.setEmail(e);
	}
	
	// accessors
	public String getName() {
		return name;
	}
	
	public String getAddress() {
		return address;
	}
	
	public double getPhoneNo() {
		return phoneNo;
	}
	
	public String getEmail() {
		return email;
	}
	
	// mutators
	public void setName(String n) {
		name = n;
	}
	
	public void setAddress(String a) {
		address = a;
	}
	
	public void setPhone(double p) {
		phoneNo = p;
	}
	
	public void setEmail(String e) {
		email = e;
	}
	

	public String toString() {
		String s = "Class: Person \nName: " + this.getName();
		
		return s;
	}

}

