package prob_11_2;

public class Test {

	public static void main(String[] args) {
		
		// istantiating a date object that holds the current date
		MyDate dateHired = new MyDate();
		
		// creating a person object with all attributes
		Person clara = new Person("Clara", "123 Arcadia Ave", 19721231234.0, "clara@gmail.com");
		
		// creating an employee object with all attributes
		Employee jack = new Employee("Jack", "124 Arcadia Ave", 19721231235.0, "jack@gmail.com", 
				"Office Alpha", 60000, dateHired);
		
		// creating a student object
		Student jeremy = new Student("Jeremy", "123 Arcadia Ave", 19721231236.0, "jeremy@gmail.com",
				"Sophomore");
		
		// creating a faculty object
		Faculty hayle = new Faculty("Hayle", "124 Arcadia Ave", 1972123127.0, "hayle@gmail.com",
				"Office Alpha", 80000, dateHired, 5.5, "General");
		
		// creating a staff object
		Staff jericho = new Staff("Jericho", "124 Arcadia Ave", 1972123128.0, "jericho@gmail.com",
				"Office Alpha", 60000, dateHired, "Lieutenant");

		//printing name of class and name of person
		System.out.println(clara.toString() + "\n");
		System.out.println(jack.toString() + "\n");
		System.out.println(jeremy.toString() + "\n");
		System.out.println(hayle.toString() + "\n");
		System.out.println(jericho.toString() + "\n");

	}

}
