package prob_11_2;

public class Faculty extends Employee{
	
	// data fields
	private double hours;
	private String rank;

	// no-arg constructor w/ default values
	public Faculty() {
		hours = 0;
		rank = null;
	}
	
	// constructor to set values
	public Faculty(String n, String a, double p, String e, String o, 
			double s, MyDate d, double h, String r) {
		super(n, a, p, e, o, s, d);
		this.setHours(h);
		this.setRank(r);
	}
	
	// accessors
	public double getHours() {
		return hours;
	}
	
	public String getRank() {
		return rank;
	}
	
	// mutators
	public void setHours(double h) {
		hours = h;
	}
	
	public void setRank(String r) {
		rank = r;
	}
	
	@Override
	public String toString() {
		String s = "Class: Faculty \nName: " + this.getName();
		
		return s;
	}

}
