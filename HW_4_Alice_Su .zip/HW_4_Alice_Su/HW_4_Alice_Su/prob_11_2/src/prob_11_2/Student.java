package prob_11_2;

public class Student extends Person{
	
	// data field
	private String status;

	// no-arg constructor
	public Student() {
		status = null;
	}
	
	// constructor that sets values
	public Student(String n, String a, double p, String e, String s) {
		super(n, a, p, e);		// to invoke superclass constructor
		this.setStatus(s);
	}
	
	// constant status mutator
	public final void setStatus(String s) {
		status = s;
	}
	
	// accessor
	public String getStatus() {
		return status;
	}
	
	@Override
	public String toString() {
		String s = "Class: Student \nName: " + this.getName();
		
		return s;
	}

}
