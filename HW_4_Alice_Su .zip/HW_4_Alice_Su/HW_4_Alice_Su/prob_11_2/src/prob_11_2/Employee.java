package prob_11_2;

public class Employee extends Person{

	// data fields
	private String office;
	private double salary;
	private MyDate date;
	
	// no-arg constructor for default values
	public Employee() {
		office = null;
		salary = 0;
		date = null;
	}
	
	// constructor to set all values
	public Employee(String n, String a, double p, String e, String o, double s, MyDate d) {
		super(n, a, p, e);		// super to invoke superclass constructor
		this.setOffice(o);
		this.setSalary(s);
		this.setDate(d);
	}
	
	// accessors
	public String getOffice() {
		return office;
	}
	
	public double getSalary() {
		return salary;
	}
	
	public MyDate getDate() {
		return date;
	}
	
	// mutators
	public void setOffice(String o) {
		office = o;
	}
	
	public void setSalary(double s) {
		salary = s;
	}
	
	public void setDate(MyDate d) {
		date = d;
	}
	
	@Override
	public String toString() {
		String s = "Class: Employee \nName: " + this.getName();
		
		return s;
	}

}
