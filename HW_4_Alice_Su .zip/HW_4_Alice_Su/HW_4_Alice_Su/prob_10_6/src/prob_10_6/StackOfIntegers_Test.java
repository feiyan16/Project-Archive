package prob_10_6;

public class StackOfIntegers_Test {

	public static void main(String[] args) {
		
		// declaring an object that is an array of int w/ size 120
		StackOfIntegers stackOfPrimes = new StackOfIntegers(120);
		
		// loop through 0 - 120 and test requirements in if statment
		for (int i = 0; i < 120; i++) {
			
			// base primes, primes btw 0 - 10
			if (i == 2 || i == 3 || i == 5 || i == 7) {
				
				// push int into stack
				stackOfPrimes.push(i);
			} else if (i > 10) {
				
				// if int divides by these no. --> not primes
				if (i % 2 == 0 || i % 3 == 0 || i % 4 == 0 || i % 5 == 0 || i % 6 == 0 || i % 7 == 0 || i % 8 == 0
						|| i % 9 == 0) {
					
					// do nothing
					System.out.print("");
				} else
					
					// otherwise, they are primes, so push into stack
					stackOfPrimes.push(i);
			}
		}
		
		// while the stack is not empty, pop and display the elements
		while (!stackOfPrimes.isEmpty()) {
			System.out.print(stackOfPrimes.pop() + " ");
		}

	}

}
