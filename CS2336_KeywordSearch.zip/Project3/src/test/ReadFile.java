package test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

class FileData {

	int id;
	String title;
	String author;
	String keywords[];

	FileData(int id, String title, String author, int kC) {
		this.id = id;
		this.title = title;
		this.author = author;
		keywords = new String[kC];
		for (int i = 0; i < kC; i++) {
			keywords[i] = null;
		}
	}

	boolean addKeyword(String keyword) {
		for (int i = 0; i < keywords.length; i++) {
			if (keywords[i] == null) {
				keywords[i] = keyword;
				return true;
			}
		}
		return false;
	}
}

public class ReadFile {
	
	BufferedReader bR;
	BinarySearchTree nodes;
	
	public FileData processFile() {
		if (bR == null) {
			System.out.println("Error: You must open the file first.");
			return null;
		} else {
			FileData fileData;
			try {
				String id = bR.readLine();
				if (id == null)
					return null;
				
				int ID = Integer.parseInt(id);
				String title = bR.readLine();
				String author = bR.readLine();
				int keywordCount = Integer.parseInt(bR.readLine());
				
				fileData = new FileData(ID, title, author, keywordCount);
				for (int i = 0; i < keywordCount; i++) {
					fileData.addKeyword(bR.readLine());
				}
				
				String space = bR.readLine();
				if ((space != null) && (!space.trim().equals(""))) {
					System.out.println("Error in file format");
					return null;
				}
			} catch (NumberFormatException e) {
				System.out.println("Error Number Expected!");
				return null;
			} catch (Exception e) {
				System.out.println("Fatal Error: " + e);
				return null;
			}
			return fileData;
		}
	}

	public ReadFile(String fileDirectory) {
		try {
			this.nodes = new BinarySearchTree();
			this.bR = new BufferedReader(new FileReader(fileDirectory));

			FileData fd;
			while ((fd = this.processFile()) != null) {
				for (int i = 0; i < fd.keywords.length; i++) {
					nodes.insert(fd.keywords[i], fd);
				}
			}
		} catch (IOException e) {
			System.out.println("IOException: file cannot be found");
			System.out.println("To fix: If you used a filename, use file directory");
		} finally {
			try {
				if (bR != null)
					bR.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
