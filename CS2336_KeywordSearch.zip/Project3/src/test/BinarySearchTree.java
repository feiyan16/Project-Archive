package test;

public class BinarySearchTree {

	Node root;

	private class Node {

		String keyword;
		Record record;
		int size;
		Node left;
		Node right;

		private Node(String k) {
			keyword = k;
		}

		private void update(Record r) {
			Record _r = this.record;
			if (_r == null) {
				this.record = r;
			} else {
				r.next = _r;
				this.record = r;
			}
		}
	}

	public BinarySearchTree() {
		this.root = null;
	}

	public void insert(String keyword, FileData fd) {
		Record recordToAdd = new Record(fd.id, fd.title, fd.author, null);
		insert(keyword, root, recordToAdd);
	}

	private void insert(String keyword, Node n, Record r) {
		if (n == null) {
			Node node = new Node(keyword);
			node.update(r);
			this.root = node;
		} else if (keyword.compareTo(n.keyword) < 0) {
			if (n.left != null) {
				insert(keyword, n.left, r);
			} else {
				Node node = new Node(keyword);
				node.update(r);
				n.left = node;
			}
		} else if (keyword.compareTo(n.keyword) > 0) {
			if (n.right != null) {
				insert(keyword, n.right, r);
			} else {
				Node node = new Node(keyword);
				node.update(r);
				n.right = node;
			}
		} else
			n.update(r);
	}

	public boolean contains(String keyword) {
		Node parentNode = root;
		while (parentNode != null) {
			if (parentNode.keyword.equals(keyword)) {
				return true;
			} else if (keyword.compareTo(parentNode.keyword) > 0) {
				parentNode = parentNode.right;
			} else
				parentNode = parentNode.left;
		}
		return false;
	}

	public Record get_records(String keyword) {
		Node n = root;
		while (contains(keyword) == true) {
			if (n.keyword.compareTo(keyword) < 0) {
				n = n.left;
			} else if (n.keyword.compareTo(keyword) > 0) {
				n = n.right;
			} else {
				break;
			}
			return n.record;
		}
		return null;
	}

	public void delete(String keyword) {
		delete(keyword, root);
	}

	private Node delete(String keyword, Node n) {
		if (n == null) {
			// do nothing, keyword doesn't exist;
		} else if (keyword.compareTo(n.keyword) < 0) {
			n.left = delete(keyword, n.left);
		} else if (keyword.compareTo(n.keyword) > 0) {
			n.right = delete(keyword, n.right);
		} else {
			if (n.right == null) {
				n = n.left;
			} else {
				// node to be deleted has 2 children
				// find the last right node
				Node replacement = lastRight(n.right);
				// replace the node to be deleted with the last right node
				n.keyword = replacement.keyword;
				n.record = replacement.record;
				n.size = replacement.size;
				// delete the last right node, 
				// it's now taken the place of the node that was deleted
				n.right = delete(replacement.keyword, n.right);
			}
		}
		return n;
	}

	private Node lastRight(Node n) {
		if (n == null) {
			return null;
		}
		if (n.left == null) {
			return n;
		}
		return lastRight(n.left);
	}

	public void print() {
		print(root);
	}

	private void print(Node t) {
		if (t != null) {
			print(t.left);
			System.out.println(t.keyword);
			Record r = t.record;
			while (r != null) {
				System.out.printf("\t%s\n", r.title);
				r = r.next;
			}
			print(t.right);
		}
	}
}
