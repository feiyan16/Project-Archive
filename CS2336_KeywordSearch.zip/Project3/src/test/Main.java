package test;

public class Main {

	public static void main(String[] args) {
		ReadFile rf = new ReadFile("/Users/feiyan/Desktop/datafile.txt");
		rf.nodes.get_records("medical").print();

		rf.nodes.print(); 
		
		rf.nodes.delete("medical");
		rf.nodes.delete("learning");
		rf.nodes.delete("concepts");

		rf.nodes.print();
	}

}
