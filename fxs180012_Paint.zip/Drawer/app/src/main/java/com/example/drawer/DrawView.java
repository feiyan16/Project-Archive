package com.example.drawer;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;

public class DrawView extends View implements View.OnTouchListener {

    Path path;
    Paint paintbrush;
    ArrayList<Brushstroke> paths = new ArrayList<>();
    int strokeColor, strokeWidth;

    @SuppressLint("ClickableViewAccessibility")
    public DrawView(Context context) {
        super(context);

        // intialize path
        path = new Path();

        // intialize paintbrush
        paintbrush = new Paint();
        paintbrush.setAntiAlias(true);
        paintbrush.setStyle(Paint.Style.STROKE);
        paintbrush.setStrokeCap(Paint.Cap.ROUND);
        paintbrush.setStrokeJoin(Paint.Join.ROUND);

        // set initial brushstroke width and color
        strokeWidth = 10;
        strokeColor = Color.BLACK;

        // set up touch listener
        this.setOnTouchListener(this);
    }

    // mutator for color
    public void setPaintColor(int color) {
        strokeColor = color;
    }

    @Override
    protected void onDraw(Canvas canvas) {

        /*
         for all the drawn paths, set the paintbrush to that path's
         color and width and draw the path with the updated paintbrush
        */
        for(Brushstroke bs : paths) {
            paintbrush.setColor(bs.color);
            paintbrush.setStrokeWidth(bs.width);
            canvas.drawPath(bs.path, paintbrush);
        }
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {

        // get event coordinates
        float x = event.getX();
        float y = event.getY();

        // check what action of the event
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            // Create new path
            path = new Path();

            // Create a brushstroke with current color, width and path;
            Brushstroke brushstroke  = new Brushstroke(strokeColor, strokeWidth, path);

            // add the brushstroke to the paths array list
            paths.add(brushstroke);

            // reset the path
            path.reset();

            // move path to coordinates
            path.moveTo(x, y);

        } else if (event.getAction() == MotionEvent.ACTION_MOVE) {

            // make line
            path.lineTo(x, y);
        }
        invalidate();
        return true;
    }
}

// Brushstroke class
class Brushstroke {

    int color; // color of brushstroke
    int width; // width of the brushstroke
    Path path; // path drawn using the brushstroke

    // constructor
    Brushstroke(int color, int width, Path path) {
        this.color = color;
        this.width = width;
        this.path = path;
    }
}