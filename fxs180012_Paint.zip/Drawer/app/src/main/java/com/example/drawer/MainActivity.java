/*
      Written by Alice Feiyan Su for CS4301.002
      Assignment 5: A paint application that allows users to draw using their finger, allowing them
      to customize their paint color and stroke width.
      NetID: fxs180012
*/

package com.example.drawer;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import com.google.android.material.slider.Slider;

public class MainActivity extends AppCompatActivity {

    LinearLayout colorButtons, controls;
    Button undo, red, green, blue, black;
    ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    Slider strokeSlider;
    DrawView drawView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // initialize draw view
        drawView = new DrawView(this.getApplicationContext());

        // set content to drawView
        setContentView(drawView);

        // initialize controls linear layout
        controls = new LinearLayout(this.getApplicationContext());
        // view will be placed side by side vertically
        controls.setOrientation(LinearLayout.VERTICAL);
        // center the views in linear layout
        controls.setGravity(Gravity.CENTER);

        // set up the undo button
        setUndoButton();

        // set up the color buttons
        setColorButtons();

        // set up the slider
        setStrokeSlider();

        // add buttons to controls linear layout
        controls.addView(undo);
        controls.addView(colorButtons);

        // add slider to controls linear layout
        controls.addView(strokeSlider);

        // add linear layout to main activity
        addContentView(controls, layoutParams);

    }

    // set up the slider
    public void setStrokeSlider() {

        // initialize slider
        strokeSlider = new Slider(this);

        // set initial value
        strokeSlider.setValue(10.0f);

        // set max and min of slider
        strokeSlider.setValueTo(20.0f);
        strokeSlider.setValueFrom(3.0f);

        // set up change listener -> set brushstroke width to value
        strokeSlider.addOnChangeListener((slider, value, fromUser) -> drawView.strokeWidth = (int) value);
    }

    // set up the undo button
    public void setUndoButton() {

        // initialize button
        undo = new Button(this.getApplicationContext());
        undo.setLayoutParams(layoutParams);
        undo.setText("Undo");

        // sets up click listener
        undo.setOnClickListener(v -> {

            // if array list of paths is not empty
            if (!drawView.paths.isEmpty()) {

                // remove the previous path from the list
                drawView.paths.remove(drawView.paths.size() - 1);

                // call onDraw again
                drawView.invalidate();
            }
        });
    }

    // set up the color buttons
    public void setColorButtons() {

        // initialize the buttons
        red = new Button(this);
        green = new Button(this);
        blue = new Button(this);
        black = new Button(this);

        // set the text
        red.setText("red");
        green.setText("green");
        blue.setText("blue");
        black.setText("black");

        // setup click listeners -> set paint color to button color
        red.setOnClickListener(v -> drawView.setPaintColor(Color.RED));

        green.setOnClickListener(v -> drawView.setPaintColor(Color.GREEN));

        blue.setOnClickListener(v -> drawView.setPaintColor(Color.BLUE));

        black.setOnClickListener(v -> drawView.setPaintColor(Color.BLACK));

        // Create linear layout
        colorButtons = new LinearLayout(this.getApplicationContext());
        colorButtons.setLayoutParams(layoutParams);
        colorButtons.setOrientation(LinearLayout.HORIZONTAL);
        colorButtons.setGravity(Gravity.CENTER);

        // add buttons to linear layout
        colorButtons.addView(red);
        colorButtons.addView(green);
        colorButtons.addView(blue);
        colorButtons.addView(black);
    }



}