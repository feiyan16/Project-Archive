package prob_10_6;

public class StackOfIntegers {
	
	public int[] primeStack;
	public int size;
	public static final int DEFAULT_CAPACITY = 16;

	// no-arg constructor with default values
	public StackOfIntegers() {
		this(DEFAULT_CAPACITY);
	}
	
	// constructor that constructs array with set size
	public StackOfIntegers(int s) {
		primeStack = new int[s];
	}
	
	// utiltiy methods pop and push
	public void push(int primeValue) {
		
		// if size of array is bigger than stack, double stack size and copy elements
		if (size >= primeStack.length) {
			int[] tempPrimeStack = new int[primeStack.length * 2];
			System.arraycopy(primeStack, 0, tempPrimeStack, 0, primeStack.length);
			primeStack = tempPrimeStack;
		}
		
		// 'push' value into stack
		primeStack[size++] = primeValue;
	}
	public int pop() {
		
		// 'pop' value into stack
		return primeStack[--size];
	}
	
	// returns top element of stack
	public int peek() {
		return primeStack[size - 1];
	}

	// check if stack is empty
	public boolean isEmpty() {
		
		// boolean is set to true when size == 0
		return size == 0;
	}
	
	// returns size of stack
	public int getSize() {
		return size;
	}
}
