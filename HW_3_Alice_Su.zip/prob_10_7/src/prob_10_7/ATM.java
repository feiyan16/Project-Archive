package prob_10_7;

import java.util.Scanner;

public class ATM {
	
	public static void main(String[] args) {
		
		// create array of Accounts
		Account[] accts = new Account[10];
		
		// instantiate Account objects in array
		for (int i = 0; i < 10; i++) {
			accts[i] = new Account(i, 100);
		}
		
		// Scanner class to read input
		Scanner input = new Scanner(System.in);
		
		// variables to store input
		int iD, choice, amt;
		
		// while loop to continue loop even after exit
		while (accts.length != 0) {
			
			// read and store id
			System.out.print("Enter an id: ");
			iD = input.nextInt();
			
			// if input is a no. from 0 - 9 --> correct id, proceed to menu
			if (iD == 0 || iD == 1 || iD == 2 || iD == 3 || iD == 4 ||
					iD == 5 || iD == 6 || iD == 7 || iD == 8 || iD == 9) {
				System.out.println("Main Menu:");
				System.out.println("1. Check Balance \n2. Withdraw \n3. Deposit \n4. Exit");
				
				// read and store choice
				System.out.print("Enter a choice: ");
				choice = input.nextInt();
				
				// 1. Check Balance
				if (choice == 1) {
					System.out.println("The balance is " + accts[iD].getBalance() + "\n");
				} 
				
				// 2. Withdraw
				else if (choice == 2) {
					
					// read and store amt to withdraw
					System.out.print("Enter amount to withdraw: ");
					amt = input.nextInt();
					
					// calls withdraw method
					accts[iD].withdraw(amt);
					System.out.print("\n");
				} 
				
				// 3. Deposit
				else if (choice == 3) {
					
					// read and store amt to deposit
					System.out.print("Enter amount to deposit: ");
					amt = input.nextInt();
					
					// calls deposit method
					accts[iD].deposit(amt);
					System.out.print("\n");
				} 
				
				// 4. Exit
				else if (choice == 4) {
					System.out.print("\n");
					
					// continue to loop beginning
					continue;
				}
			} 
			
			// if choice entered was not 0 - 9, then re-start loop to ask for correct id
			else {
				System.out.println("Please enter correct ID");
				continue;
			}	
		}
	}
}
