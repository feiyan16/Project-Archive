package prob_10_7;

public class Account {
	// private data fields
	private int id;
	private double balance;
	private double annualInterestRate;
	private String dateCreated;

	// no-arg constructor to instantiate w/ default values
	public Account() {
		id = 0;
		balance = 0;
		annualInterestRate = 0;
		dateCreated = null;
	}
	
	// constructor to set id and balance
	public Account(int i, double b) {
		id = i;
		balance = b;
	}

	// mutators to set id, balance, date and annual interest rate
	public void setId(int i) {
		id = i;
	}
	
	public void setBalance(double b) {
		balance = b;
	}
	
	public void setDate(String d) {
		dateCreated = d;
	}
	
	public void setAnnualInterestRate(double a) {
		annualInterestRate = a;
	}
	
	// accessors to get date, id, balance, and annual interest rate
	public String getDateCreated() {
		return dateCreated;
	}
	
	public int getId() {
		return id;
	}
	
	public double getBalance() {
		return balance;
	}
	
	public double getAnnual() {
		return annualInterestRate;
	}
	
	// annual = 12 months, hence divide by 12
	public double getMonthlyInterestRate() {
		return annualInterestRate/12;
	}
	
	// get $monthlyinterst, not %rate
	public double getMonthlyInterest() {
		double monthlyIntRate = this.getMonthlyInterestRate() / 100;
		return balance * monthlyIntRate;
	}
	
	// subtracts amt from balance, and returns new balance
	public double withdraw(double amt) {
		double newBalance = balance - amt;
		balance = newBalance;
		return balance;
	}
	
	// adds amt to balance, and returns new balance
	public double deposit(double amt) {
		double newBalance = balance + amt;
		balance = newBalance;
		return balance;
	}
}
