package prob_11_2;

public class Staff extends Employee{

	// data field
	private String title;
	
	// no-arg constructor
	public Staff() {
		title = null;
	}
	
	// constructor to set values
	public Staff(String n, String a, double p, String e, String o, double s, MyDate d, String t) {
		super(n, a, p, e, o, s, d);
		this.setTitle(t);
	}
	
	// accessor
	public String getTitle() {
		return title;
	}

	// mutator
	public void setTitle(String t) {
		title = t;
	}
	
	// override
	public String toString() {
		String s = "Class: Staff \nName: " + this.getName();
		
		return s;
	}
}
