package prob_11_2;

import java.util.*;

public class MyDate {
	
	// data fields
	private int year;
	private int month;
	private int day;
	
	// no-arg constructor that sets obj to current date
	public MyDate() {
		
		GregorianCalendar date = new GregorianCalendar();
		
		year = date.get(Calendar.YEAR);
		month = date.get(Calendar.MONTH);
		day = date.get(Calendar.DAY_OF_MONTH);
		
	}
	
	// constructor that sets date from elapsed time
	public MyDate(long t) {
		
		GregorianCalendar date = new GregorianCalendar();
		
		date.setTimeInMillis(t);
		
		year = date.get(Calendar.YEAR);
		month = date.get(Calendar.MONTH);
		day = date.get(Calendar.DAY_OF_MONTH);
		
	}
	
	// constructor that sets the year, month, and dates
	public MyDate(int y, int m, int d) {
		year = y;
		month = m;
		day = d;
	}
	
	// accessors
	public int getYear() {
		return year;
	}
	
	public int getMonth() {
		return month;
	}
	
	public int getDay() {
		return day;
	}
	
	// sets new date for object using elapsed time
	public void setDate(long elapsedTime) {	
		
		GregorianCalendar date = new GregorianCalendar();
		
		date.setTimeInMillis(elapsedTime);

		year = date.get(Calendar.YEAR);
		month = date.get(Calendar.MONTH);
		day = date.get(Calendar.DAY_OF_MONTH);
	}

}
