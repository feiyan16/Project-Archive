#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>

int main(int argc, char **argv){
    
    char string[100];
    strcpy(string, "netstat -aont | grep \"`hostname -i`:");
    strcat(string, argv[1]);
    strcat(string, " \" ");
    system(string);
    
    return 0;
}
