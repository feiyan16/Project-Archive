#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>

int main(int argc, char **argv){

   // run netstat command - to grep any with port# 20-29

   system("netstat -aont | grep \"`hostname -i`:2[0-9] \" ");

	
   return 0;
}
