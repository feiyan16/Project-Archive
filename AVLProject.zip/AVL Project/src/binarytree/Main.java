package binarytree;

public class Main {

	public static void main(String[] args) {
		BinaryTree tree = new BinaryTree();
		
		tree.printPreOrder(tree.root);
		
		System.out.println("\n\n");
		
		if (tree.verifyIfBST(tree.root, null, null) == true) {
			System.out.println("The tree is a Binary Search Tree");
		} else {
			System.out.println("The tree is not a Binary Search Tree");
		}
		
		System.out.println("\n");
		
		Height height = new Height();
		if (tree.verifyIfAVL(tree.root, height) == true) {
			System.out.println("The tree is AVL balanced");
		} else {
			System.out.println("The tree is not AVL balanced");
		}
	}
}
