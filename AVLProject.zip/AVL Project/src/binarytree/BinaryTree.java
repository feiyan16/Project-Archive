package binarytree;

import java.util.Random;

class Node {
	int key;
//	int height;
	Node left;
	Node right;
	
	Node(int key) {
		this.key = key;
//		this.height = 0;
	}
}

public class BinaryTree {

	private Random random = new Random();
	
	Node root;

	public BinaryTree() {
		int size = generateSize();
		int key = generateKey();
		System.out.println("Printing a tree with " + size + " nodes pre-ordered:\n");
		this.root = generateTree(size, key);
	}
	
	Node generateTree(int size, int key) {
		if (size == 0) { 
			return null; 
		}
		
		Node node = new Node(key);
		int leftSize = random.nextInt(size);
		int rightSize = size - leftSize - 1;
		
		node.left = generateTree(leftSize, generateKey());
		node.right = generateTree(rightSize, generateKey());
		
		return node;
	}
	
/****************** UTILITY FUNCTIONS ********************/
	
	void printPreOrder(Node node) {
		if (node == null) {
			return;
		}
		System.out.print(node.key + " ");
		printPreOrder(node.left);
		printPreOrder(node.right);
		
	}
	
	int generateSize() {
		return (int) (Math.random() * 101);
	}
	
	int generateKey() {
		return (int) (Math.random() * 21);
	}
	
// ONLY NEEDED FOR OPTION 1'S FUNCTION
//	int heightOf(Node node) {
//		if (node == null) { return -1; } 
//		
//		return Math.max(heightOf(node.left), heightOf(node.right)) + 1;
//	}
	
	Boolean verifyIfBST(Node node, Node left, Node right) {
		if (node == null) {
			return true;
		}
		
		if (left != null && left.key >= node.key) {
			return false;
		}
		
		if (right != null && right.key <= node.key) {
			return false;
		}
		
		return verifyIfBST(node.left, left, node) && verifyIfBST(node.right, node, right);
	}
	
// OPTION 1: O(N^2)

//	Boolean verifyIfAVL(Node node) {
//		int heightOfLeft, heightOfRight;
//		if (node == null) {
//			return true;
//		}
//		
//		heightOfLeft = heightOf(node.left);
//		heightOfRight = heightOf(node.right);
//		
//		int balance = Math.abs(heightOfLeft - heightOfRight);
//		
//		if (balance <= 1 && verifyIfAVL(node.left) && verifyIfAVL(node.right)) {
//			return true;
//		}
//		
//		return false;
//	}
	
// OPTION 2: O(N)
	Boolean verifyIfAVL(Node node, Height height) {
		
		// Means that the tree/subtree is empty, hence height = -1 and is balanced.
		if (node == null) {
			height.height = -1;
			return true;
		}
		
//		Height objects to hold height of left and right nodes' heights
		Height leftHeight = new Height();
		Height rightHeight = new Height();
		
//		Verify left and right nodes' balance
		Boolean left = verifyIfAVL(node.left, leftHeight);
		Boolean right = verifyIfAVL(node.right, rightHeight);
		
//		store height of left and right nodes' heights in variables
		int heightOfLeft = leftHeight.height;
		int heightOfRight = rightHeight.height;
		
//		get the height of parent node/root
		height.height = Math.max(heightOfLeft, heightOfRight) + 1;
		
//		if height difference btw L and R is more than one node return false, 
//		otherwise return boolean of left node's balance and right nodes' balance
//		if either one is unbalanced, then the tree is unbalanced even if parent node is balanced.
		if (Math.abs(heightOfLeft - heightOfRight) > 1) {
			return false;
		} else {
			return left && right;
		}
	}
	
}

// Height class to store height
class Height {
	int height = -1;
}
