
public class Book {
	
	String title;
	String author;

	public Book() {}
	
	public Book(String title, String author) {
		this.title = title;
		this.author = author;
	}
	
	void print() {
		System.out.println(title.replaceAll("_", " ") + " by " + author);
	}

}
