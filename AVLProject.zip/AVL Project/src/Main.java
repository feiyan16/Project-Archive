
public class Main {

	public static void main(String[] args) {
		ReadFile rf = new ReadFile("/Users/feiyan/Desktop/Books.txt");
		System.out.println("\n\nPreorder traversal of the tree:\n");
		rf.tree.preOrder(rf.tree.root);
		System.out.println("\nTotal balance of the tree = " + rf.tree.getBalance(rf.tree.root));
	}

}
