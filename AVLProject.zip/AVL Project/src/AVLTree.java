

// Node class
class AVLNode {
	String ISBN;
	Book book;
	int height;
	AVLNode left;
	AVLNode right;
	
	AVLNode(String ISBN, Book book) {
		this.book = book;
		this.ISBN = ISBN;
		this.height = 0;
	}
}

public class AVLTree {
	
	AVLNode root;
	
	AVLNode insert(AVLNode node, String ISBN, Book book) {
		
		// Basically a normal BST insertion, keep traversing right/left until end of tree.
		if (node == null) {
			AVLNode Node = new AVLNode(ISBN, book);
			return Node;
		} else if (ISBN.compareTo(node.ISBN) < 0) {
			node.left = insert(node.left, ISBN, book);
		} else if (ISBN.compareTo(node.ISBN) > 0) {
			node.right = insert(node.right, ISBN, book);
		} else // this will never happen, since ISBNs don't repeat... at least, I don't think so...
			return node;
		
		// Update the height of the tree
		node.height = max(heightOf(node.left), heightOf(node.right)) + 1;
		
		// get balance of node
		int nodeBalance = getBalance(node);
		
		// left left case
		if (nodeBalance > 1 && ISBN.compareTo((node.left).ISBN) < 0) {
			System.out.println("Imbalance occurred at inserting ISBN " + ISBN + ", fixed in Right Rotation");
			return rotateRight(node);
		} 
		
		// right right case
		if (nodeBalance < -1 && ISBN.compareTo((node.right).ISBN) > 0) {
			System.out.println("Imbalance occurred at inserting ISBN " + ISBN + ", fixed in Left Rotation");
			return rotateLeft(node);
		} 
		
		// left right case 
		if (nodeBalance > 1 && ISBN.compareTo((node.left).ISBN) > 0) {
			System.out.println("Imbalance occurred at inserting ISBN " + ISBN + ", fixed in Right-Left Rotation");
			node.left = rotateLeft(node.left);
			return rotateRight(node);
		} 
		
		// right left case
		if (nodeBalance < -1 && ISBN.compareTo((node.right).ISBN) < 0) {
			System.out.println("Imbalance occurred at inserting ISBN " + ISBN + ", fixed in Left-Right Rotation");
			node.right = rotateRight(node.right);
			return rotateLeft(node);
		} 
		
		return node;
	}
	
/*************************** UTILITY FUNCTIONS *****************************/
	
	int heightOf(AVLNode node) {
		if (node == null) { return -1; } 
		return node.height;
	}
	
	int getBalance(AVLNode node) {
		if (node == null) { return 0; }
		return heightOf(node.left) - heightOf(node.right);
	}
	
	int max(int height1, int height2) {
		return (height1 > height2) ? height1 : height2;
	}
	
	void preOrder(AVLNode node) { 
	    if (node != null) {
	    	node.book.print();
            System.out.println("ISBN " + node.ISBN);
            System.out.println("Height = " + node.height + "\n");
            preOrder(node.left); 
            preOrder(node.right); 
	    }
	} 
	
	AVLNode rotateRight(AVLNode node) {
		AVLNode replacementNode = node.left;
		AVLNode rNodeRightSubtree = replacementNode.right;
		
		node.left = rNodeRightSubtree;
		replacementNode.right = node;
		
		node.height = max(heightOf(node.left), heightOf(node.right)) + 1;
		replacementNode.height = max(heightOf(replacementNode.left), heightOf(replacementNode.right)) + 1;
		
		return replacementNode;
	}
	
	AVLNode rotateLeft(AVLNode node) {
		AVLNode replacementNode = node.right;
		AVLNode rNodeLeftSubtree = replacementNode.left;
		
		node.right = rNodeLeftSubtree;
		replacementNode.left = node;
		
		node.height = max(heightOf(node.left), heightOf(node.right)) + 1;
		replacementNode.height = max(heightOf(replacementNode.left), heightOf(replacementNode.right)) + 1;
		
		return replacementNode;
	}
}
