import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReadFile {
	BufferedReader bR;
	AVLTree tree;

	public ReadFile(String fileDirectory) {
		try {
			this.bR = new BufferedReader(new FileReader(fileDirectory));
			this.tree = new AVLTree();
			
			FileData fileData;
			
			// loop through the entire text file and store each line in fileData
			while((fileData = this.processFile()) != null) {
				
				// initialize book object with fileData's data...
				Book book = new Book(fileData.title, fileData.author);
//				System.out.println(fileData.ISBN);
				
				// insert that data into the tree
				tree.root = tree.insert(tree.root, fileData.ISBN, book);
			}
		} catch (FileNotFoundException e) {
			System.out.println("IOException: file cannot be found");
			System.out.println("To fix: If you used a filename, use file directory");
		} finally {
			if (bR != null) { try {
				bR.close();
			} catch (IOException e) {
				e.printStackTrace();
			} }
		}
	}
	
	// function to process the text in file.txt
	public FileData processFile() {
		if (bR == null) {
			System.out.println("Error: You must open the file first.");
			return null;
		} else {
			FileData fileData;
			try {
				// read until a \n, basically a full line of text
				String data = bR.readLine();
				
				// if nothing, aka reached end of text
				if (data == null) { return null; };
				
				// split each line at the <space>
				String dataArray[] = data.trim().split(" ");
				
				// store each token/element in respective strings
				String ISBN = dataArray[0];
				String title = dataArray[1];
				String author = dataArray[2];
				
				// initialize the filedata object
				fileData = new FileData(ISBN, title, author);
				
			} catch (NumberFormatException e) {
				System.out.println("Error Number Expected!");
				e.printStackTrace();
				return null;
			} catch (Exception e) {
				System.out.println("Fatal Error: " + e);
				e.printStackTrace();
				return null;
			}
			return fileData;
		}
	}

}

// Class to create object that will hold all the file's text data
class FileData {
	String ISBN;
	String title;
	String author;
	
	FileData(String ISBN, String title, String author) {
		this.ISBN = ISBN;
		this.title = title;
		this.author = author;
	}
}