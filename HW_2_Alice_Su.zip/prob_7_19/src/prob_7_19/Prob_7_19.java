package prob_7_19;

import java.util.Scanner;

public class Prob_7_19 {

	public static void main(String[] args) {
		
		System.out.print("Enter size of list: ");
		Scanner input = new Scanner(System.in);
		int size = input.nextInt();
		
		//Array creation
		int[] list = new int[size];
		
		System.out.print("Enter list: ");
		
		//to fill array with input
		for (int i = 0; i < size; i++) {
			list[i] = input.nextInt();
		}
		
		//calling method
		//if it is sorted, then print the list is already sorted
		//else, if it is not sorted, then print the list is not sorted
		if (isSorted(list) == true) {
			System.out.println("The list is already sorted.");
		} else
			System.out.println("The list is not sorted.");
		
	}
	
	// method to check if sorted or not
	public static boolean isSorted(int[] list) {
		
		// to make indication of the start and end of the array
		int startOfArray = 0;
		int endOfArray = list.length - 1;
		
		// declaring boolean status for if sorted or not
		boolean status = true;
		
		// if it the first element is bigger than last element, 
		// then it is not sorted so status = false
		if(list[startOfArray] > list[endOfArray]) {
			status = false;
			
		// otherwise, for the rest of the elements
		// compare if the element directly after startOfArray is bigger or smaller
		// if bigger then increment startOfArray to check do next comparison
		// otherwise status becomes false
		} else {
			for (int i = 1; i < list.length; i++) {
				if (list[startOfArray] <= list[i]) {
					startOfArray++;
				} else {
					status = false;
				}
			}
		}
		
		//return status on whether is sorted or not
		return status;
	}

}
