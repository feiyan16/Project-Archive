package prob_7_32;

import java.util.Scanner;

public class prob_7_32 {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		//user input to get array size
		System.out.print("Enter list size: ");
		int size = input.nextInt();
		
		//array creation; allocation of memory
		int[] list = new int[size];
		
		//for loop to fill array
		System.out.print("Enter list content: ");
		for (int i = 0; i < size; i++) {
			list[i] = input.nextInt();
		}
		
		//calling method, passing list as argument
		partition(list);
		
		//printing partitioned list
		System.out.print("After the partition, the list is ");
		for (int i = 0; i < size; i++) {
			System.out.print(list[i] + " ");
		}
	}
	
	//partition method:
	public static int partition(int[] list) {
		
		//declaring a pivot being the first element
		int pivot = list[0];
		
		//declaring pivot location as the position of first element
		int pivotLocation = 0;
		
		//declaring the end of the array
		int endOfArray = list.length - 1;
		
		
		//creating while loop
		while (pivotLocation < endOfArray) {
			
			//if the the element after the pivot is smaller/equals
			if (list[pivotLocation+1] <= pivot) {
				list[pivotLocation] = list[pivotLocation+1];
				list[pivotLocation+1] = pivot;
				pivotLocation++;
			} else {
				int temp = list[endOfArray];
				list[endOfArray] = list[pivotLocation + 1];
				list[pivotLocation+1] = temp;
				endOfArray--;
			}
		}
		
		return pivotLocation;
	}

}
