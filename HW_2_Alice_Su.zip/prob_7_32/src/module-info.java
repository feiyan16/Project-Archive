module prob_7_32 {
}