package prob_7_11;

import java.util.Scanner;

public class Prob_7_11 {

	public static void main(String[] args) {
		
		//constant variable of array size
		final int s = 10;
		
		//declaring double variables to store values
		double standardDeviation, mean;
		
		System.out.print("Enter 10 numbers: ");
		
		Scanner input = new Scanner(System.in);
		
		//array creation
		double[] numbers = new double[s];
		
		//filling up the array
		for (int i = 0; i < s; i++) {
			numbers[i] = input.nextDouble();
		}
		
		//calling methods to store variable with return values
		standardDeviation = deviation(numbers);
		mean = mean(numbers);
		
		//format printing to make it pretty
		System.out.printf("The mean is %4.2f", mean);
		System.out.print("\n");
		System.out.printf("The standard deviation is %7.5f", standardDeviation);
	}
	
	//to fine standard deviation of elements
	public static double deviation(double[] x) {
		
		//calling mean method to store return value in mean
		//declaring sum for storing summation of all element
		double mean = mean(x), sum = 0.0;
		
		//for loop to go through each element
		for (int i = 0; i < x.length; i++) {
			
			//sum = sum + (x[i] - mean)^2
			//and x will increment to next element
			sum += (x[i] - mean) * (x[i] - mean);
		}
		
		//to calculate square route, using power method in math class
		//square-root of a no. is just that no. ^0.5
		double standardDeviation = Math.pow(sum/(x.length-1), 0.5);
		
		//return value
		return standardDeviation;
	}
	
	//to find mean of elements
	public static double mean(double[] x) {
		
		//declaring sum for storing summation of all element
		double sum = 0.0;
		
		//to loop through elements so x will increase
		for (int i = 0; i < x.length; i++) {
			
			//sum = sum + x[i];
			//and sum will increase as x increments
			sum += x[i];
		}
		
		//calculating mean: sum of elements/no. of elements
		double mean = sum/x.length;
		
		//return value
		return mean;
	}
}
