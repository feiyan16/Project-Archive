module prob_7_11 {
}