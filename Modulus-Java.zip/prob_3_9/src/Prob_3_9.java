
import java.util.Scanner;

public class Prob_3_9 {

	public static void main(String[] args) {

	  /*Declaring variables that will store the digits of 
		the ISBN no.*/
		int d9,d8,d7,d6,d5,d4,d3,d2,d1; 
		//d(n) = digit n, where n = 1-9;
		
	  /*Declaring variables that will store the decreasing
	    shortened ISBN.*/
		int i8,i7,i6,i5,i4,i3,i2,i1;
		//i(n) = ISBN with n digits, where n = 1-8;
		
		//Scanner class
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the first 9 digits of an ISBN as integer: ");
		int isbn = input.nextInt(); //take in an integer
		input.close();
		//close scanner class
		
	  /* e.g. 013601267
	     Using modulus to get the remainder, which will be the last digit
	     For d9, using the example ISBN,
	     013601267 % 10 = 7, so d9 = 7;
	     use this logic for all the digits.
	  */	
		
	  /* To get the remaining 8 digits ISBN, i8
	     take ISBN w/ 8+1 digits, so i9 = 013601267;
	     i9 - d9 --> 013601267 - 7 = 013601260;
	     then take (i9 - d9) value and divide it by 10 
	     to remove the 0: 013601260/10 = 01360126.0 
	     Integer type will only use/show: 01360126
	     use this logic to get i7-i1.
	  */
		d9 = isbn % 10;	   //= 7
		i8 = (isbn-d9)/10; //= 01360126 --> based of example  
		d8 = i8 % 10;      //= 6
		i7 = (i8-d8)/10;   //= 0136012
		d7 = i7 % 10;	   //= 2
		i6 = (i7-d7)/10;   //= 013601
		d6 = i6 % 10;	   //= 1
		i5 = (i6-d6)/10;   //= 01360
		d5 = i5 % 10;	   //= 0
		i4 = (i5-d5)/10;   //= 0136
		d4 = i4 % 10;	   //= 6
		i3 = (i4-d4)/10;   //= 013
		d3 = i3 % 10;	   //= 3
		i2 = (i3-d3)/10;   //= 01
		d2 = i2 % 10;      //= 1
		i1 = (i2-d2)/10;   //= 0
		d1 = i1;		   //= 0
		
		//formula to get the last digit, from the textbook;
		int d10 = (d1*1+d2*2+d3*3+d4*4+d5*5+d6*6+d7*7+d8*8+d9*9) % 11;
		
		
	/* if (d10 = 10) {
	 * 	and if (d1 = 0){ --> because 013 will be printed as 13 instead of 013
	 * 		then print out ("The ISBN ... "0" ... "X") 
	 * 	} else --> if just d10 = 10
	 * 		then print out ("The ISBN ... "X")
	 * } else if (d1 = 0) --> only {
	 * 		then print out ("The ISBN ... "0" ... d10)
	 * 	} else 
	 * 		then print out ("The ISBN ... isbn + d10) --> per normal.
	*/
		
		if (d10 == 10) { 
			if (d1 == 0) {
				System.out.print("The ISBN-10 number is: " + "0" + isbn + "X");
			} else 
				System.out.print("The ISBN-10 number is: " + isbn + "X");
		} else if (d1 == 0) {
			System.out.print("The ISBN-10 number is: " + "0" + isbn + d10);
		} else 
			System.out.print("The ISBN-10 number is: " + isbn + d10);
	}
}
		
		