import java.util.Scanner;

public class Prob_3_28 {
	public static void main(String[] args) {
		
	/*
	 * Declaring double variables to store center coordinates, 
	 * width & height for both rectangles;
	 */
		double center_x1, center_y1, width1, height1;
		double center_x2, center_y2, width2, height2;
	/*
	 *  Declaring double variables to store the width coordinates
	 *  and height coordinates for both rectangles;
	 */
		double w1_co_start, w1_co_end, h1_co_start, h1_co_end;
		double w2_co_start, w2_co_end, h2_co_start, h2_co_end;
		
	//  scanner class
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter r1's center x-coordinates: ");
		center_x1 = input.nextDouble(); //for double inputs
		System.out.print("Enter r1's center y-coordinates: ");
		center_y1 = input.nextDouble();
		System.out.print("Enter r1's center width: ");
		width1 = input.nextDouble();
		System.out.print("Enter r1's center height: ");
		height1 = input.nextDouble();
		
		System.out.print("\n");
		
		System.out.print("Enter r2's center x-coordinates: ");
		center_x2 = input.nextDouble();
		System.out.print("Enter r2's center y-coordinates: ");
		center_y2 = input.nextDouble();
		System.out.print("Enter r2's center width: ");
		width2 = input.nextDouble();
		System.out.print("Enter r2's center height: ");
		height2 = input.nextDouble();
		
		System.out.print("\n");
		
		input.close();
		
	//  close scanner class;
		
		
	/*
	 *  Finding out coordinates for width and height
	 *  w1_co_start = width of rectangle 1 - starting coordinate
	 *  same template for height and ending coordinates;
	 *  
	 *  Formula Explanation:
	 *  Example: 
	 *  width = 4, height = 2, center coordinates = (2,5)
	 *              _____________4_____________
	 *         (0,6)|            |            |(4,6)
	 *              | 			 1            |
	 *              |            |            |
	 *              |<-----2---->.(2,5)       2
	 *              |                         |
	 *              |                         |
	 *         (0,4)|_________________________|(4,4)
	 *  
	 *  w1_co_start = 2 - (4/2) = 2 - 2 = 0
	 *  w1_co_end = 2 + (4/2) = 2 + 2 = 4 
	 *  h1_co_start = 5 - (2/2) = 5 - 1 = 4
	 *  h1_co_end = 5 + (2/2) = 5 + 1 = 6
	 */
		w1_co_start = center_x1 - (width1/2);
		w1_co_end = center_x1 + (width1/2);
		w2_co_start = center_x2 - (width2/2);
		w2_co_end = center_x2 + (width2/2);
		h1_co_start = center_y1 - (height1/2);
		h1_co_end = center_y1 + (height1/2);
		h2_co_start = center_y2 - (height2/2);
		h2_co_end = center_y2 + (height2/2);
	/*
	 *  Explanation for if statements:
	 *  
	 *  						______________
	 *   						|			 |
	 *                        e |	   .     |
	 *  						|____________|
	 *  							_____________f
	 *  					________|           |______
	 * 					    |       |     .     |  ___|________
	 *  			________|___    |___________|  |          |
	 *     			|		   |                   |     .    |  a
	 *  	c		|     .    |                   |__________|
	 *  			|__________|	      .           |   ____________
	 *  		__________	|                         |   |          | 
 	 *  		|		 |	|         ____________    |   |     .    |  b
	 *     d   	|    .   |	|      g  |          |    |   |__________| 
	 *  		|________|	|_________|     .    |____|
	 *  							  |__________|	
	 *                           ______________
	 *                           |            |
	 *                      h    |      .     |
	 *                           |____________|
	 *  
	 *  
	 *  Scenario on the right side:
	 *  If (center of rectangle 2 is outside of rectangle 1)
	 *  	and if (w2_co_start is less than w1_co_end)  --> top rectangle
	 *  		then print out ("r2 overlaps r1")
	 *  	and if (w2_co start is greater than w1_co_end) --> bottom rectangle
	 *  		then print out ("r2 does not overlap r1")
	 *  
	 *  repeat same logic with scenario c and d
	 *  repeat same logic with scenario e,f,g, and h, 
	 *  but with height coordinates, so all the h1_co_start, etc.
	 *  
	 *  The last if statement:
	 *  If (r2's center coordinates is within the width and height of r1)
	 *  	then print ("r2 is inside r1")
	 */

		if (center_x2 > w1_co_end) {
			if(w2_co_start < w1_co_end) {
				System.out.print("r2 overlaps r1");
			}
			if (w2_co_start > w1_co_end) {
				System.out.print("r2 does not overlap r1");
			}
		} else if (center_x2 < w1_co_start) {
			if (w2_co_end > w1_co_start) {
				System.out.print("r2 overlaps r1");
			} 
			if (w2_co_end < w1_co_start) {
				System.out.print("r2 does not overlap r1");
			}
		} else if (center_y2 > h1_co_end) {
			if(h2_co_start < h1_co_end) {
				System.out.print("r2 overlaps r1");
			}
			if (h2_co_start > h1_co_end) {
				System.out.print("r2 does not overlap r1");
			}
		} else if (center_y2 < h1_co_start) {
			if (h2_co_end > h1_co_start) {
				System.out.print("r2 overlaps r1");
			} 
			if (h2_co_end < h1_co_start) {
				System.out.print("r2 does not overlap r1");
			}
		} else if (center_x2 >= w1_co_start && center_x2 <= w1_co_end && 
				center_y2 >= h1_co_start && center_y2 <= h1_co_end) {
			System.out.print("r2 is inside r1.");
		} 
	}
}
