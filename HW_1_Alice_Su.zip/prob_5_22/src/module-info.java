module prob_5_22 {
}