package prob_5_22;

import java.util.Scanner;

public class prob_5_22 {

	public static void main(String[] args) {
		
		//declaration of variables to hold values
		int loanAmt, nYears;
		double monthlyIntRate, annualIntRate, monthlyPayment,
		totalPayment, interest, principal, balance;
		
		//scanner class
		Scanner input = new Scanner(System.in);
		
		//User input
		System.out.print("Loan Amount: ");
		loanAmt = input.nextInt();
		System.out.print("Number of Years: ");
		nYears = input.nextInt();
		System.out.print("Annual Interest Rate: ");
		annualIntRate = input.nextDouble();
		
		System.out.print("\n");
		
		//calculation of monthly interest rate (txtbk listing 2.9)
		monthlyIntRate = annualIntRate / 1200;
		
		//calculation of monthly payment (txtbk listing 2.9)
		monthlyPayment = loanAmt * monthlyIntRate / 
				(1 - 1 / Math.pow(1 + monthlyIntRate, nYears * 12));
		
		//calculation of total payment (txtbk listing 2.9)
		totalPayment = monthlyPayment * nYears * 12;
		
		//format printing to get 2 decimal places
		System.out.printf("Monthly Payment: %5.2f", monthlyPayment);
		System.out.print("\n");
		System.out.printf("Total Payment: %5.2f", totalPayment);
		System.out.println("\n");
		
		//headers
		System.out.printf("Payment#\tInterest\tPrincipal\tBalance\n");
		
		//initializing balance amount
		balance = loanAmt;
		
		/*
		 * for the given number of months,
		 * monthly interest = monthly interest rate * balance
		 * monthly principal = monthly payment - interest
		 * balance = balance - principal
		 * print out: 
		 * month	interest	principal	balance
		 * formatted to 2 decimal places for all amounts
		 */
		for(int i = 1; i <= nYears * 12; i++) {
			interest = monthlyIntRate * balance;
			principal = monthlyPayment - interest;
			balance = balance - principal;
			
			System.out.printf(i +  "\t\t%5.2f\t\t%5.2f\t\t%5.2f",
					interest, principal, balance);
			System.out.print("\n");
		}

	}

}
