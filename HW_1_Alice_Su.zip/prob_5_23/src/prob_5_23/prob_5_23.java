package prob_5_23;

public class prob_5_23 {

	public static void main(String[] args) {
		
		//sum calculated from right to left
		double sumRtoL = 0.0;
		
		/*
		 * n = denominator
		 * for denominator starting with 50000
		 * sum = sum + 1/n --> sum = 0.0 + 1/50000
		 * (sum is now 1/50000, not 0.0 anymore)
		 * Then decrease n by 1, and repeat till n = 1
		 */
		for (int n = 50000; n > 0; n--) {
			sumRtoL += 1.0/(double)n;
		}
		System.out.println("The sum from right to left = " + sumRtoL);
		
		//sum calculated from left to right
		double sumLtoR = 0.0;
		
		/*
		 * for denominator starting with 1
		 * sum = sum + 1/n --> sum = 0.0 + 1/1
		 * (sum is not 1, not 0.0 anymore)
		 * Then increase n by 1, and repeat till n = 50000
		 */
		for (int n = 1; n <= 50000; n++) {
			sumLtoR += 1.0/(double)n;
		}
		System.out.println("The sum from left to right = " + sumLtoR);
		
		System.out.println("The difference between the 2 sums is " + (sumRtoL - sumLtoR));
	}
}
