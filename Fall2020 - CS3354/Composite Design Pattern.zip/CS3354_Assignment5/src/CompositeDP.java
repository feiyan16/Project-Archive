import java.util.ArrayList;

public class CompositeDP {

	public static void main (String [] args) {
		GeometricShapes gs1 = new GeometricShapes("gs1");
		Rectangle r1 = new Rectangle("r1", 10, 5);
		Rectangle r2 = new Rectangle("r2", 13, 8);
		gs1.addChild(r1);
		gs1.addChild(r2);
		
		Triangle t1 = new Triangle("t1", 10, 5);
		Triangle t2 = new Triangle("t1", 13, 8);
		
		GeometricShapes gs3 = new GeometricShapes("gs3");
		gs3.addChild(gs1);
		gs3.addChild(t1);
		gs3.addChild(t2);
		System.out.println(gs3.showArea());
		
		ArrayList<Geometry> gs3Nodes = gs3.getChild();
		String gs3Desc = "gs3 is the root, it has 1 composite node and 2 leaf nodes -- ";
		for(int i = 0; i < gs3Nodes.size(); i++) {
			gs3Desc += (gs3Nodes.get(i).getName() + " ");
		}
		System.out.println(gs3Desc);
		
		System.out.println("t1's parent is " + t1.getParent().getName());
		System.out.println("r1's parent is " + r1.getParent().getName());
		
		ArrayList<Geometry> gs1Nodes = gs1.getChild();
		String gs1Desc = "gs1's children are ";
		for(int i = 0; i < gs1Nodes.size(); i++) {
			gs1Desc += (gs1Nodes.get(i).getName() + " ");
		}
		System.out.println(gs1Desc);
	}
	
}

//Component
abstract class Geometry {
	
	abstract String showArea();
	abstract String getName();
	abstract Geometry getParent();
	abstract void setParent(Geometry g);
	abstract ArrayList<Geometry> getChild();
	abstract void addChild(Geometry g);
	abstract void removeChild(Geometry g);
	
}

// Leaf
class Rectangle extends Geometry {
	
	String name;
	Geometry parent;
	double width;
	double height;
	
	Rectangle(String n, double w, double h) {
		name = n;
		width = w;
		height = h;
	}
	
	@Override
	String showArea() {
		return "Area of " + this.name + " is " + (width * height) + "\n";
	}

	@Override
	String getName() {
		return this.name;
	}

	@Override
	Geometry getParent() {
		return parent;
	}

	@Override
	void setParent(Geometry g) {
		parent = g;
	}
	

	@Override
	ArrayList<Geometry> getChild() { return null; }

	@Override
	void addChild(Geometry g) {}

	@Override
	void removeChild(Geometry g) {}
}

// Leaf
class Triangle extends Geometry {
	
	String name;
	Geometry parent;
	double width;
	double height;

	Triangle(String n, double w, double h) {
		name = n;
		width = w;
		height = h;
	}
	
	@Override
	String showArea() {
		return "Area of " + this.name + " is " + (0.5 * width * height) + "\n";
		
	}

	@Override
	String getName() {
		return this.name;
	}

	@Override
	Geometry getParent() {
		return parent;
	}

	@Override
	void setParent(Geometry g) {
		parent = g;
	}

	@Override
	ArrayList<Geometry> getChild() { return null; }

	@Override
	void addChild(Geometry g) {}

	@Override
	void removeChild(Geometry g) {}
}

// Composite
class GeometricShapes extends Geometry {
	
	String name;
	Geometry parent;
	
	ArrayList<Geometry> shapes = new ArrayList<Geometry>();
	
	GeometricShapes(String n) {
		name = n;
	}

	@Override
	String showArea() {
		
		String area = "";
		
		for(Geometry g : shapes) {
			area += g.showArea();
		}
		
		return area;
	}

	@Override
	String getName() {
		return this.name;
	}
	
	@Override
	Geometry getParent() {
		return parent;
	}

	@Override
	void setParent(Geometry g) {
		parent = g;
	}
	
	@Override
	void addChild(Geometry g) {
		shapes.add(g);
		g.setParent(this);
	}
	
	@Override
	void removeChild(Geometry g) {
		shapes.remove(g);
	}
	
	@Override
	ArrayList<Geometry> getChild() {
		return shapes;
	}
	
}