
public class NewReleasedMovie extends Movie {

	public NewReleasedMovie(String title) {
		super(title, 0, 0, 3);
	}

}
