
public class ChildrensMovie extends Movie {

	public ChildrensMovie(String title) {
		super(title, 3, 1.5, 1.5);
	}

}
